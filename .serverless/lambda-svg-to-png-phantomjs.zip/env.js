module.exports = {
  BUKKET: 'lambda-svg-to-png-phantomjs',
  REGION: 'ap-northeast-1'
};
