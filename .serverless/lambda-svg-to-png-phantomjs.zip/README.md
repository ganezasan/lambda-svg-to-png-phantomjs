# Png Converter

# install
```
npm install serverless -g
npm install
```

# config your aws acount

[Set up your Provider credentials](https://github.com/serverless/serverless/blob/master/docs/02-providers/aws/01-setup.md)

# deploy
```
serverless deploy
```

# do api use lamdba
```
serverless invoke -f charts -p event.json
```
